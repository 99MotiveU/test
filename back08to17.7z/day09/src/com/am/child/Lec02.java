package com.am.child;

public class Lec02 {
	public int su1=1111;
	protected int su2=2222;
	int su3=3333;
	private int su4=4444;
	
	protected Lec02() {
		// TODO Auto-generated constructor stub
	}
}
