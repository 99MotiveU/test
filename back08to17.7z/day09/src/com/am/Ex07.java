package com.am;

public class Ex07 {

	public static void main(String[] args) {
		double su1=java.lang.Math.PI;
		System.out.println(Math.max(5,2));
		System.out.println(Math.min(5,2));
		System.out.println(Math.abs(1));
		System.out.println(Math.abs(-1));
		System.out.println(Math.floor(3.14));//����
		System.out.println(Math.ceil(3.14));//�ø�
		System.out.println(Math.round(3.14));//�ݿø�
	}

}
