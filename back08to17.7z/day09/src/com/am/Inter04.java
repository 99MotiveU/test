package com.am;

interface Inter04{ //extends Inter02,Inter03{
	void func03();
}
