package com.am;

import java.util.*;

public class Ex01 {

	public static void main(String[] args) {
		//�ߺ� ���
		List list = new ArrayList();
		list = new LinkedList();
		
		//
		Queue que = new LinkedList();
		Deque que2 = new LinkedList();
		Stack stack = new Stack();
		
		//
		Vector vec1 = new Vector();
		Vector vec2 = new Stack();
		
		//�ߺ� ����
		Set set1 = new HashSet();
		set1.add("ù��°");
		set1.add("�ι�°");
		set1.add("����°");
		set1.add("�׹�°");
		
		Iterator ite = set1.iterator();
		while(ite.hasNext()) {
			System.out.println(ite.next());
		}
	}

}
