package com.am;

public class Ex04 {

	public Ex04(int a) {}
	Ex04(boolean boo) {}
	public Ex04(String msg){}
	

	public static void main(String[] args) {

		

	}

}
