package com.am;

public class Ex03 {

	public static int su3 = 3333;

	public static int su4 = 4444;

	public static void main(String[] args) {

	}

	class Ex04 {
	}

//	private class Ex05{}

}
