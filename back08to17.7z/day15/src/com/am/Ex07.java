package com.am;

import java.awt.Frame;

public class Ex07 {

	public static void main(String[] args) {
		Frame f = new Frame();
		f.setTitle("����");
		f.setCursor(Frame.WAIT_CURSOR);
		f.setCursor(Frame.HAND_CURSOR);
		
		f.setLocation(0, 0);
		f.setSize(300, 200);
		f.setVisible(true);

	}

}
